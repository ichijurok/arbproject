<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

class Ndrahello extends Module
{
    public function __construct()
    {
        $this->name = 'ndrahello';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Ndra';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = ['min' => '1.7', 'max' => _PS_VERSION_];
        $this->bootstrap = false;
        parent::__construct();
        $this->displayName = $this->l('Ndra Hello');
        $this->description = $this->l('Menampilkan pesan sederhana di footer.');
    }

    public function install()
    {
        return parent::install() && $this->registerHook('displayFooter');
    }

    public function uninstall()
    {
        return parent::uninstall();
    }

    public function hookDisplayFooter($params)
    {
        return '<p style="text-align:center;">Halo dari modul buatan sendiri!</p>';
    }
}
